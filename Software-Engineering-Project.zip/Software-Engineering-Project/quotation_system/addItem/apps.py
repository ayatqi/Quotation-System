from django.apps import AppConfig


class AdditemConfig(AppConfig):
    name = 'addItem'
